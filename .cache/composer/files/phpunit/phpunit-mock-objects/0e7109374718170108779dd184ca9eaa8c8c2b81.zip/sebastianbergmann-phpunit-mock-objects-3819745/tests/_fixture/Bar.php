<?php
class Bar
{
    public function doSomethingElse()
    {
        return 'result';
    }
}
