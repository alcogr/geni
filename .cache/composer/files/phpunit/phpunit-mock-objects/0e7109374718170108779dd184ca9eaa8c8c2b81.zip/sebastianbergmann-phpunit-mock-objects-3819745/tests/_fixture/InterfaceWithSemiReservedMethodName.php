<?php
interface InterfaceWithSemiReservedMethodName
{
    public function unset();
}
