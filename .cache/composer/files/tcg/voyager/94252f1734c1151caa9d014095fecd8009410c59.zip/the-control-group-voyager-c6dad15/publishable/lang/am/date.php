<?php

return [
    'last_week' => 'Վերջին շաբաթ',
    'last_year' => 'Վերջին տարի',
    'this_week' => 'Այս շաբաթ',
    'this_year' => 'Այս տարի',
];
