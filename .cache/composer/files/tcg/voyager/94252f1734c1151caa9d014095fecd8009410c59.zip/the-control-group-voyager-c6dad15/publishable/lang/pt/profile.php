<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Editar o meu perfil',
    'edit_user'     => 'Editar Utilizador',
    'password'      => 'Password',
    'password_hint' => 'Deixar vazio para manter o valor atual',
    'role'          => 'Função',
    'user_role'     => 'Função do Utilizador',
];
