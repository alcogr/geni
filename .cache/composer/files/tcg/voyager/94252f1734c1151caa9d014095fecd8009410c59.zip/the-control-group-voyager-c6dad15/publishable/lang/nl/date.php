<?php

return [
    'last_week' => 'Vorige week',
    'last_year' => 'Vorig jaar',
    'this_week' => 'Deze week',
    'this_year' => 'Dit jaar',
];
