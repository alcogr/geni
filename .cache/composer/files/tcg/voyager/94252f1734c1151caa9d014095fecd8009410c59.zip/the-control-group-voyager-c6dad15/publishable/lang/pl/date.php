<?php

return [
    'last_week' => 'Poprzedni tydzień',
    'last_year' => 'Poprzedni rok',
    'this_week' => 'Bieżący tydzień',
    'this_year' => 'Bieżący rok',
];
