<?php

return [
    'last_week' => 'هفته پیش',
    'last_year' => 'سال پیش',
    'this_week' => 'این هفته',
    'this_year' => 'امسال',
];
