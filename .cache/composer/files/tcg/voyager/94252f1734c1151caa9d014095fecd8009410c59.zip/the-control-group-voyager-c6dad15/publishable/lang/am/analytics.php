<?php

return [
    'by_pageview'            => 'Ըստ Էջի դիտման',
    'by_sessions'            => 'Ըստ Սեսիաների',
    'by_users'               => 'Ըստ Օգտատերերի',
    'no_client_id'           => 'Վերլուծությունը դիտելու համար հարկավոր է ստանալ Google Analytics-ի client id եւ այն ավելացնել <code> google_analytics_client_id </code> բանալին Ձեր կարգավորումներում: Ստացեք Ձեր բանալին Ձեր Google developer console-ից:',
    'set_view'               => 'Ընտրել դիտում',
    'this_vs_last_week'      => 'Այս շաբաթը համեմատած վերջին շաբաթվա',
    'this_vs_last_year'      => 'Այս տարին համեմատած վերջին տարվա',
    'top_browsers'           => 'Թոփ բրուզերները',
    'top_countries'          => 'Թոփ երկրները',
    'various_visualizations' => 'Տարբեր տեսանելություններ',
];
