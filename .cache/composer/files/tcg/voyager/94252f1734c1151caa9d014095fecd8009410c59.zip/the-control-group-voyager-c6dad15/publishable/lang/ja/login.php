<?php

return [
    'loggingin'    => 'ログイン',
    'signin_below' => 'サインイン:',
    'welcome'      => 'Voyagerへようこそ. The Missing Admin for Laravel',
];
