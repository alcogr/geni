<?php

return [
    'footer_copyright'  => 'Stworzone z <i class="voyager-heart"></i> przez',
    'footer_copyright2' => 'Do stworzenia potrzebny był rum, dużo rumu',
];
