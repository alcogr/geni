<?php

return [
    'page'           => 'Faqe | Faqet',
    'page_link_text' => 'Shikoni të gjitha faqet',
    'page_text'      => 'Ju keni: count: string në databazën tuaj. Klikoni butonin më poshtë'
    .' për të parë të gjitha faqet. ',
    'post'           => 'Posta | Postime',
    'post_link_text' => 'Shiko të gjitha postimet',
    'post_text'      => 'Ju keni: count: string në databazën tuaj. Klikoni butonin '
    .'më poshtë për të parë të gjitha postimet. ',
    'user'           => 'Përdorues',
    'user_link_text' => 'Shikoni të gjithë përdoruesit',
    'user_text'      => 'Ju keni: count: string në databazën tuaj. Klikoni butonin'
    .' më poshtë për të parë të gjithë përdoruesit. ',
];
