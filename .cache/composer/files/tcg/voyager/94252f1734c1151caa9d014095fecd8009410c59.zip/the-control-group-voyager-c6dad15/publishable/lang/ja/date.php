<?php

return [
    'last_week' => '先週',
    'last_year' => '昨年',
    'this_week' => '今週',
    'this_year' => '今年',
];
