<?php

return [
    'avatar'           => 'Avatar',
    'edit'             => 'Mein Profil bearbeiten',
    'edit_user'        => 'Benutzer bearbeiten',
    'password'         => 'Passwort',
    'password_hint'    => 'Leer lassen um das Bisherige zu behalten',
    'role'             => 'Rolle',
    'roles'            => 'Rollen',
    'role_default'     => 'Standard-Rolle',
    'roles_additional' => 'Zusätzliche Rollen',
    'user_role'        => 'Benutzerrolle',
];
