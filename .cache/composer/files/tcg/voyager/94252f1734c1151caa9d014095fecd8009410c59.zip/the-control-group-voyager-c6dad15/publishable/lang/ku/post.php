<?php

return [
    'additional_fields'=> 'خانەی زیادە',
    'category'         => 'بەشی بابەت',
    'content'          => 'ناوەڕۆکی بابەت',
    'details'          => 'ووردەکاری بابەت',
    'excerpt'          => 'کورتە <small>کورتەیەک دەربارەی ئەم بابەتە</small>',
    'image'            => 'وێنەی بابەت',
    'meta_description' => 'ڕونکردنەوەی مێتا (Meta)',
    'meta_keywords'    => 'کلیلەووشەی مێتا (Meta)',
    'new'              => 'دروستکردنی بابەتی نوێ',
    'seo_content'      => 'ناوەڕۆکی SEO',
    'seo_title'        => 'ناونیشانی SEO',
    'slug'             => 'لینک',
    'status'           => 'باری بابەت',
    'status_draft'     => 'درافت',
    'status_pending'   => 'چاوەڕوانی',
    'status_published' => 'بڵاوکردنەوە',
    'title'            => 'تایتڵی بابەت',
    'title_sub'        => 'ناونیشانێک بۆ بابەتەکەت',
    'update'           => 'نوێکردنەوەی بابەت',
];
