<?php

return [
    'footer_copyright'  => 'Dibuat dengan <i class="voyager-heart"></i> oleh',
    'footer_copyright2' => 'Dibuat dengan rum dan lebih banyak rum',
];
