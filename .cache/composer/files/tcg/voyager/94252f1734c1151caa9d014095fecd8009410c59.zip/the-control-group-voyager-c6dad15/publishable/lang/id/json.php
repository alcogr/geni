<?php

return [
    'invalid'           => 'Json tidak valid',
    'invalid_message'   => 'Sepertinya JSON kamu tidak valid.',
    'valid'             => 'Json Valid',
    'validation_errors' => 'Validasi error',
];
