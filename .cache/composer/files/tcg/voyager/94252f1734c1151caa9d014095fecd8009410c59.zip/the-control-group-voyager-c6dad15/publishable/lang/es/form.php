<?php

return [
    'field_password_keep'          => 'Dejar vacío para mantener el mismo',
    'field_select_dd_relationship' => 'Asegúrese de configurar la relación apropiada en el método :method de la clase :class.',
    'type_checkbox'                => 'Casilla de verificación',
    'type_codeeditor'              => 'Editor de código',
    'type_file'                    => 'Archivo',
    'type_image'                   => 'Imagen',
    'type_radiobutton'             => 'Botón de radio',
    'type_richtextbox'             => 'Caja de texto enriquecido',
    'type_selectdropdown'          => 'Lista desplegable',
    'type_textarea'                => 'Área de texto',
    'type_textbox'                 => 'Caja de texto',
];
