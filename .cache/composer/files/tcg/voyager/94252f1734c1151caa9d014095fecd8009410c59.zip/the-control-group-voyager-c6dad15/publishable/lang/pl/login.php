<?php

return [
    'loggingin'    => 'Trwa logowanie',
    'signin_below' => 'Wprowadź poniżej dane logowania:',
    'welcome'      => 'Witaj w Voyager. Brakujący panel administracyjny Laravel',
];
